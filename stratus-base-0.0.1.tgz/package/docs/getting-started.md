# Getting Started with StratusBase

`StratusBase` is a client-side synchronisation library that lets you build offline-first web applications using browser Origin Private File System (OPFS) storage and sync with remote storage backends (Dropbox, Google Drive, GitHub, S3). It supports end-to-end AES-256 encrypted chunking.

---

## 1. Installation & Imports

```typescript
import { StratusBase, generateSecurePassword } from 'stratus-base';
import { MiddlewareZipChunk } from 'stratus-base';
import { S3Storage } from 'stratus-base';
```

---

## 2. Choosing and Initialising a Backend

Choose the storage provider you want to use. For key-based setups like Amazon S3:

```typescript
const backend = new S3Storage({
	bucket: 'my-app-vault',
	region: 'us-east-1',
	accessKeyId: 'YOUR_ACCESS_KEY',
	secretAccessKey: 'YOUR_SECRET_KEY'
});
```

_(For interactive OAuth backends like Dropbox or Google Drive, consult their specific setup guides in the `docs/` folder.)_

---

## 3. Configuring Middleware

Middlewares control how files are stored remotely.

### Encrypted ZIP Chunking (`MiddlewareZipChunk`)

Packs files into sequential, password-encrypted ZIP archives. This hides filenames, sizes, and file structures from the remote host (ideal for privacy/Obsidian-style apps).

```typescript
// Always generate or load a strong password (at least 16 chars, ideally 64)
const password = localStorage.getItem('vault_password') || generateSecurePassword(64);

const middleware = new MiddlewareZipChunk({
	chunkSizeLimit: 5 * 1024 * 1024, // 5MB target chunk size
	password: password, // Enforces AES-256 encryption
	atomic: true // Enables atomic write-then-rename if supported
});
```

---

## 4. Initialising StratusBase

Pass the backend and middleware into the main sync client:

```typescript
const client = new StratusBase({
	backend,
	localRoot: '/my-notes-vault', // Cache directory inside browser OPFS
	middleware,
	sparse: false // If true, downloads file contents on-demand (lazy)
});
```

> **Credential Persistence**: On instantiation, `StratusBase` automatically looks up and restores any valid credentials saved in `localStorage` for the same backend configuration.

---

## 5. Checking Authentication (`isConfigured`)

Before interacting with remote storage, check whether the backend has valid credentials and is authenticated:

```typescript
const isAuth = await client.isConfigured();

if (!isAuth) {
	// Not authenticated: Prompt the user to connect or start the OAuth flow
	console.log('Backend requires authentication.');
} else {
	// Authenticated and ready to check remote setup or sync
	console.log('Backend is authenticated.');
}
```

### Initiating the Authentication Flow

If `isConfigured()` returns `false`, initiate provider-specific authentication directly via the `client`:

#### OAuth Providers (Dropbox, Google Drive)
1. **Redirect to OAuth login**:
   ```typescript
   const redirectUri = window.location.origin + '/oauth/callback';
   const authUrl = await client.getAuthUrl(redirectUri);
   window.location.href = authUrl;
   ```
2. **Handle OAuth callback**:
   On your callback route, exchange the authorization code for credentials:
   ```typescript
   // Dropbox / OAuth Code Flow
   const params = new URLSearchParams(window.location.search);
   const code = params.get('code');
   if (code) {
       await client.exchangeCode(code, redirectUri);
       // Credentials are automatically persisted by StratusBase to localStorage!
   }

   // Google Drive
   const result = GoogleDriveStorage.handleAuthCallback();
   if (result?.mode === 'redirect') {
       client.setCredentials(result.credentials);
   }
   ```

#### Token Providers (GitHub)
Prompt the user for their Personal Access Token (PAT) and set credentials:
```typescript
client.setCredentials({ accessToken: userEnteredToken });
// Automatically persisted by StratusBase to localStorage
```

---

## 6. Checking Remote Setup (`isSetUp`)

Before beginning sync or onboarding, check if the remote repository has already been initialised:

```typescript
const isSetUp = await client.isSetUp();

if (!isSetUp) {
	// First-time onboarding (e.g. prompt to create/save encryption password, seed initial files)
	console.log('No existing data detected on remote. Starting onboarding...');
} else {
	// Existing data detected (e.g. prompt for existing vault password)
	console.log('Existing data detected on remote.');
}
```

- **`MiddlewareIndividualFile`**: Returns `true` if any files or folders exist on the remote (excluding `/sync.lock`).
- **`MiddlewareZipChunk`**: Returns `true` if at least one `archive_chunk_*.7z` chunk exists on the remote.

---

## 7. Working with Files (CRUD)

`StratusBase` exposes standard filesystem operations that interact with the local OPFS cache:

### Writing a file (Text Helper)

```typescript
await client.writeTextFile('/notes/intro.md', '# Welcome to StratusBase');
```

### Reading a file (Text Helper)

```typescript
const markdownText = await client.readTextFile('/notes/intro.md');
```

### Writing raw binary

```typescript
const content = new Uint8Array([1, 2, 3]);
await client.writeFile('/data.bin', content);
```

### Reading raw binary

```typescript
const bytes = await client.readFile('/data.bin');
```

### Listing a directory

```typescript
const files = await client.listDirectory('/notes');
for (const file of files) {
	console.log(file.name, file.size, file.modifiedAt);
}
```

### Deleting a file

```typescript
await client.deleteFile('/notes/intro.md');
```

---

## 8. Synchronising with Remote

To push local updates and pull remote changes, run the `sync()` method:

```typescript
try {
	const result = await client.sync();
	console.log(
		`Sync completed! Created: ${result.created.length}, Updated: ${result.updated.length}`
	);
} catch (err) {
	if (err.name === 'SyncConflictError') {
		console.warn('Sync finished with conflicts. Handle resolution.');
	} else if (err.name === 'SyncLockedError') {
		console.warn(
			`Sync is locked by ${err.lockDetails.clientName} (started at ${err.lockDetails.date}).`
		);
	} else {
		console.error('Sync failed:', err);
	}
}
```

### Checking and Breaking Locks (Optional)

If you want to check if the remote repository is locked before triggering a sync, or force a sync by breaking an existing lock:

```typescript
// Check if backend is locked
const available = await client.canSync();

// Force-clear any existing lock and trigger a sync
const result = await client.forceSync();
```

---

## 9. Event System

`StratusBase` extends the native browser `EventTarget` class. You can attach standard event listeners to monitor sync lifecycles:

```typescript
client.addEventListener('syncstart', () => {
	console.log('Sync process started...');
});

client.addEventListener('sync', (e) => {
	const result = (e as CustomEvent).detail;
	console.log('Sync finished successfully:', result);
});

client.addEventListener('conflict', (e) => {
	const conflict = (e as CustomEvent).detail;
	console.warn(`File in conflict: ${conflict.path}`);

	// Trigger conflict resolution flow
});

client.addEventListener('error', (e) => {
	const error = (e as CustomEvent).detail;
	console.error('Sync error occurred:', error);
});

client.addEventListener('reauthrequired', (e) => {
	const { backend, reason } = (e as CustomEvent).detail;
	console.warn(`Re-authentication required for ${backend} (${reason})`);
	// Prompt the user to re-authenticate or renew expired OAuth tokens
});
```

---

## 10. Handling Conflicts

When a conflict occurs (i.e. both local and remote have newer modifications), `StratusBase` writes the remote content to an updates file (`/path/to/file_updates.ext`) and flags the original file in a `'conflict'` state.

To resolve it, invoke `resolveConflict` with the target path and the final resolved bytes:

```typescript
// Resolve conflict by keeping local or remote content, or custom merges:
const resolvedBytes = new TextEncoder().encode('Merged Content Here');

await client.resolveConflict('/notes/intro.md', resolvedBytes);
// The temporary updates file is automatically cleaned up and the file is marked dirty to push next sync.
```

---

## 11. Logging Out (`logout`)

To securely clear the local cache, wipe persisted credentials in `localStorage`, and disconnect backend sessions:

```typescript
// Deletes the local OPFS storage folder recursively, removes stored credentials, and disconnects the backend
await client.logout();
```
